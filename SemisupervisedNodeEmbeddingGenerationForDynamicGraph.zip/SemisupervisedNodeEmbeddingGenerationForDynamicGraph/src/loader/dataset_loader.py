import os
from os.path import join, exists

from datetime import datetime
import networkx as nx
import pandas as pd
from pandas import Series
from utils.graph_utils import set_graph_node_features,set_graph_edge_weight


def load_dataset(dataset_name,dumpFolderName='dump'):
    '''
    This function is responsible of receiving the dataset name and access the right folder, read and create the graph.
    Args:
        dataset_name: str - the name of the graph dataset

    Returns:
        graph_nx: networkx - graph of the dataset with all needed attributes
        folder_path: str - the path to the dataset folder, in order to dump files in it
    '''
    folder_path = join(r"../data", dataset_name)
    dump_folder = join(folder_path, dumpFolderName)
    #

    if dataset_name == 'PPI':
        graph_path = join(folder_path, "interactions_with_dates.csv")
        graph_df = pd.read_csv(graph_path, sep=',', usecols=['id1', 'id2', 'discovery date'])
        graph_df = graph_df[~pd.isnull(graph_df['discovery date'])]
        graph_df['time'] = graph_df['discovery date'].map(lambda x: eval(x).year)
        graph_df.rename({'id1': 'from', 'id2': 'to'}, axis='columns', inplace=True)
        graph_nx = nx.from_pandas_edgelist(graph_df, 'from', 'to', edge_attr=['time'], create_using=nx.Graph())
    elif dataset_name == 'DPPIN-Babu':
        graph_path = join(folder_path, "Dynamic_PPIN.txt")
        node_feature_path=join(folder_path, "Node_Features.txt")
        headers = [*pd.read_csv(node_feature_path, nrows=1)]
        node_features_df = pd.read_csv(node_feature_path, sep=',', usecols=[c for c in headers if c != headers[1]])
        node_features_df=node_features_df.set_index(headers[0]).T.to_dict('list')
        graph_df = pd.read_csv(graph_path, sep=',', usecols=['from', 'to', 'time','edgeweight'])
        graph_nx = nx.from_pandas_edgelist(graph_df, 'from', 'to', edge_attr=['time', 'edgeweight'], create_using=nx.Graph())
        nx.set_node_attributes(graph_nx, node_features_df,"features")
        set_graph_edge_weight(graph_nx)

    elif dataset_name == 'DPPIN-Breitkreutz':
        graph_path = join(folder_path, "Dynamic_PPIN.txt")
        node_feature_path=join(folder_path, "Node_Features.txt")
        headers = [*pd.read_csv(node_feature_path, nrows=1)]
        node_features_df = pd.read_csv(node_feature_path, sep=',', usecols=[c for c in headers if c != headers[1]])
        node_features_df=node_features_df.set_index(headers[0]).T.to_dict('list')
        graph_df = pd.read_csv(graph_path, sep=',', usecols=['from', 'to', 'time','edgeweight'])
        graph_nx = nx.from_pandas_edgelist(graph_df, 'from', 'to', edge_attr=['time', 'edgeweight'], create_using=nx.Graph())
        nx.set_node_attributes(graph_nx, node_features_df,"features")
        set_graph_edge_weight(graph_nx)
    elif dataset_name == 'DPPIN-Gavin':
        graph_path = join(folder_path, "Dynamic_PPIN.txt")
        node_feature_path=join(folder_path, "Node_Features.txt")
        headers = [*pd.read_csv(node_feature_path, nrows=1)]
        node_features_df = pd.read_csv(node_feature_path, sep=',', usecols=[c for c in headers if c != headers[1]])
        node_features_df=node_features_df.set_index(headers[0]).T.to_dict('list')
        graph_df = pd.read_csv(graph_path, sep=',', usecols=['from', 'to', 'time','edgeweight'])
        graph_nx = nx.from_pandas_edgelist(graph_df, 'from', 'to', edge_attr=['time', 'edgeweight'], create_using=nx.Graph())
        nx.set_node_attributes(graph_nx, node_features_df,"features")
        set_graph_edge_weight(graph_nx)
    elif dataset_name == 'DPPIN-Hazbun':
        graph_path = join(folder_path, "Dynamic_PPIN.txt")
        node_feature_path=join(folder_path, "Node_Features.txt")
        headers = [*pd.read_csv(node_feature_path, nrows=1)]
        node_features_df = pd.read_csv(node_feature_path, sep=',', usecols=[c for c in headers if c != headers[1]])
        node_features_df=node_features_df.set_index(headers[0]).T.to_dict('list')
        graph_df = pd.read_csv(graph_path, sep=',', usecols=['from', 'to', 'time','edgeweight'])
        graph_nx = nx.from_pandas_edgelist(graph_df, 'from', 'to', edge_attr=['time', 'edgeweight'], create_using=nx.Graph())
        nx.set_node_attributes(graph_nx, node_features_df,"features")
        set_graph_edge_weight(graph_nx)
    elif dataset_name == 'DPPIN-Ho':
        graph_path = join(folder_path, "Dynamic_PPIN.txt")
        node_feature_path=join(folder_path, "Node_Features.txt")
        headers = [*pd.read_csv(node_feature_path, nrows=1)]
        node_features_df = pd.read_csv(node_feature_path, sep=',', usecols=[c for c in headers if c != headers[1]])
        node_features_df=node_features_df.set_index(headers[0]).T.to_dict('list')
        graph_df = pd.read_csv(graph_path, sep=',', usecols=['from', 'to', 'time','edgeweight'])
        graph_nx = nx.from_pandas_edgelist(graph_df, 'from', 'to', edge_attr=['time', 'edgeweight'], create_using=nx.Graph())
        nx.set_node_attributes(graph_nx, node_features_df,"features")
        set_graph_edge_weight(graph_nx)
    elif dataset_name == 'DPPIN-Krogan_MALDI':
        graph_path = join(folder_path, "Dynamic_PPIN.txt")
        node_feature_path=join(folder_path, "Node_Features.txt")
        headers = [*pd.read_csv(node_feature_path, nrows=1)]
        node_features_df = pd.read_csv(node_feature_path, sep=',', usecols=[c for c in headers if c != headers[1]])
        node_features_df=node_features_df.set_index(headers[0]).T.to_dict('list')
        graph_df = pd.read_csv(graph_path, sep=',', usecols=['from', 'to', 'time','edgeweight'])
        graph_nx = nx.from_pandas_edgelist(graph_df, 'from', 'to', edge_attr=['time', 'edgeweight'], create_using=nx.Graph())
        nx.set_node_attributes(graph_nx, node_features_df,"features")
        set_graph_edge_weight(graph_nx)
    elif dataset_name == 'DPPIN-Ito':
        graph_path = join(folder_path, "Dynamic_PPIN.txt")
        node_feature_path=join(folder_path, "Node_Features.txt")
        headers = [*pd.read_csv(node_feature_path, nrows=1)]
        node_features_df = pd.read_csv(node_feature_path, sep=',', usecols=[c for c in headers if c != headers[1]])
        node_features_df=node_features_df.set_index(headers[0]).T.to_dict('list')
        graph_df = pd.read_csv(graph_path, sep=',', usecols=['from', 'to', 'time','edgeweight'])
        graph_nx = nx.from_pandas_edgelist(graph_df, 'from', 'to', edge_attr=['time', 'edgeweight'], create_using=nx.Graph())
        nx.set_node_attributes(graph_nx, node_features_df,"features")
        set_graph_edge_weight(graph_nx)
    elif dataset_name == 'DPPIN-Krogan_LCMS':
        graph_path = join(folder_path, "Dynamic_PPIN.txt")
        node_feature_path=join(folder_path, "Node_Features.txt")
        headers = [*pd.read_csv(node_feature_path, nrows=1)]
        node_features_df = pd.read_csv(node_feature_path, sep=',', usecols=[c for c in headers if c != headers[1]])
        node_features_df=node_features_df.set_index(headers[0]).T.to_dict('list')
        graph_df = pd.read_csv(graph_path, sep=',', usecols=['from', 'to', 'time','edgeweight'])
        graph_nx = nx.from_pandas_edgelist(graph_df, 'from', 'to', edge_attr=['time', 'edgeweight'], create_using=nx.Graph())
        nx.set_node_attributes(graph_nx, node_features_df,"features")
        set_graph_edge_weight(graph_nx)
    elif dataset_name == 'DPPIN-Lambert':
        graph_path = join(folder_path, "Dynamic_PPIN.txt")
        node_feature_path=join(folder_path, "Node_Features.txt")
        headers = [*pd.read_csv(node_feature_path, nrows=1)]
        node_features_df = pd.read_csv(node_feature_path, sep=',', usecols=[c for c in headers if c != headers[1]])
        node_features_df=node_features_df.set_index(headers[0]).T.to_dict('list')
        graph_df = pd.read_csv(graph_path, sep=',', usecols=['from', 'to', 'time','edgeweight'])
        graph_nx = nx.from_pandas_edgelist(graph_df, 'from', 'to', edge_attr=['time', 'edgeweight'], create_using=nx.Graph())
        nx.set_node_attributes(graph_nx, node_features_df,"features")
        set_graph_edge_weight(graph_nx)
    elif dataset_name == 'DPPIN-Tarassov':
        graph_path = join(folder_path, "Dynamic_PPIN.txt")
        node_feature_path=join(folder_path, "Node_Features.txt")
        headers = [*pd.read_csv(node_feature_path, nrows=1)]
        node_features_df = pd.read_csv(node_feature_path, sep=',', usecols=[c for c in headers if c != headers[1]])
        node_features_df=node_features_df.set_index(headers[0]).T.to_dict('list')
        graph_df = pd.read_csv(graph_path, sep=',', usecols=['from', 'to', 'time','edgeweight'])
        graph_nx = nx.from_pandas_edgelist(graph_df, 'from', 'to', edge_attr=['time', 'edgeweight'], create_using=nx.Graph())
        nx.set_node_attributes(graph_nx, node_features_df,"features")
        set_graph_edge_weight(graph_nx)
    elif dataset_name == 'DPPIN-Uetz':
        graph_path = join(folder_path, "Dynamic_PPIN.txt")
        node_feature_path=join(folder_path, "Node_Features.txt")
        headers = [*pd.read_csv(node_feature_path, nrows=1)]
        node_features_df = pd.read_csv(node_feature_path, sep=',', usecols=[c for c in headers if c != headers[1]])
        node_features_df=node_features_df.set_index(headers[0]).T.to_dict('list')
        graph_df = pd.read_csv(graph_path, sep=',', usecols=['from', 'to', 'time','edgeweight'])
        graph_nx = nx.from_pandas_edgelist(graph_df, 'from', 'to', edge_attr=['time', 'edgeweight'], create_using=nx.Graph())
        nx.set_node_attributes(graph_nx, node_features_df,"features")
        set_graph_edge_weight(graph_nx)
    elif dataset_name == 'DPPIN-Yu':
        graph_path = join(folder_path, "Dynamic_PPIN.txt")
        node_feature_path=join(folder_path, "Node_Features.txt")
        headers = [*pd.read_csv(node_feature_path, nrows=1)]
        node_features_df = pd.read_csv(node_feature_path, sep=',', usecols=[c for c in headers if c != headers[1]])
        node_features_df=node_features_df.set_index(headers[0]).T.to_dict('list')
        graph_df = pd.read_csv(graph_path, sep=',', usecols=['from', 'to', 'time','edgeweight'])
        graph_nx = nx.from_pandas_edgelist(graph_df, 'from', 'to', edge_attr=['time', 'edgeweight'], create_using=nx.Graph())
        nx.set_node_attributes(graph_nx, node_features_df,"features")
        set_graph_edge_weight(graph_nx)
    ################################################################### Below not protein dataset

    elif dataset_name == 'ARXCIT':
        graph_path = join(folder_path, "citationArxivTimeAsMonth.txt")
        graph_df = pd.read_csv(graph_path, sep='\t', usecols=['from', 'to', 'time'])
        graph_nx = nx.from_pandas_edgelist(graph_df, 'from', 'to', edge_attr=['time'], create_using=nx.Graph())
    elif dataset_name == 'APSCIT':
        graph_path = join(folder_path, "apsCitationProcessed.txt")
        graph_df = pd.read_csv(graph_path, sep='\t', usecols=['from', 'to', 'time'])
        graph_nx = nx.from_pandas_edgelist(graph_df, 'from', 'to', edge_attr=['time'], create_using=nx.Graph())
    elif dataset_name == 'FBWP':
        graph_path = join(folder_path, "Facebook.txt")
        graph_df = pd.read_csv(graph_path, sep='\t', usecols=['from', 'to', 'time'])
        graph_nx = nx.from_pandas_edgelist(graph_df, 'from', 'to', edge_attr=['time'], create_using=nx.Graph())
    elif dataset_name == 'IDC':
        graph_path = join(folder_path, "infectiousDisease.txt")
        graph_df = pd.read_csv(graph_path, sep='\t', usecols=['from', 'to', 'time'])
        graph_nx = nx.from_pandas_edgelist(graph_df, 'from', 'to', edge_attr=['time'], create_using=nx.Graph())
    elif dataset_name == 'MITC':
        graph_path = join(folder_path, "realHumanContactMIT.txt")#MITHumanContacTimeAsDay,  realHumanContactMIT, MITHumanContacTimeAsDay
        graph_df = pd.read_csv(graph_path, sep=',', usecols=['from', 'to', 'time'])
        graph_nx = nx.from_pandas_edgelist(graph_df, 'from', 'to', edge_attr=['time'], create_using=nx.Graph())
    elif dataset_name == 'AMAZUI':
        graph_path = join(folder_path, "amazonTBPNormalizedTime.txt")
        graph_df = pd.read_csv(graph_path, sep='\t', usecols=['from', 'to', 'time'])
        graph_nx = nx.from_pandas_edgelist(graph_df, 'from', 'to', edge_attr=['time'], create_using=nx.Graph())
    elif dataset_name == 'SOFFAVUI':
        graph_path = join(folder_path, "stackoverflowSmall.txt")
        graph_df = pd.read_csv(graph_path, sep=',', usecols=['from', 'to', 'time'])
        graph_nx = nx.from_pandas_edgelist(graph_df, 'from', 'to', edge_attr=['time'], create_using=nx.Graph())
    elif dataset_name == 'YOUTUBEUI':
        graph_path = join(folder_path, "youTubeTemporalNormalized.txt")
        graph_df = pd.read_csv(graph_path, sep='\t', usecols=['from', 'to', 'time'])
        graph_nx = nx.from_pandas_edgelist(graph_df, 'from', 'to', edge_attr=['time'], create_using=nx.Graph())
    elif dataset_name == 'NFUI':
        graph_path = join(folder_path, "netflix5k_result_time_desc.txt")
        graph_df = pd.read_csv(graph_path, sep='\t', usecols=['from', 'to', 'time'])
        graph_nx = nx.from_pandas_edgelist(graph_df, 'from', 'to', edge_attr=['time'], create_using=nx.Graph())
    elif dataset_name == 'MLUI':
        graph_path = join(folder_path, "movielens.txt")
        graph_df = pd.read_csv(graph_path, sep='\t', usecols=['from', 'to', 'time'])
        graph_nx = nx.from_pandas_edgelist(graph_df, 'from', 'to', edge_attr=['time'], create_using=nx.Graph())
    elif dataset_name == 'LFMUI':
        graph_path = join(folder_path, "lastFm.csv")
        graph_df = pd.read_csv(graph_path, sep='\t', usecols=['from', 'to', 'time'])
        graph_nx = nx.from_pandas_edgelist(graph_df, 'from', 'to', edge_attr=['time'], create_using=nx.Graph())
    elif dataset_name == 'ESMUI':
        graph_path = join(folder_path, "e21PayMentHourofDay.txt")
        graph_df = pd.read_csv(graph_path, sep='\t', usecols=['from', 'to', 'time'])
        graph_nx = nx.from_pandas_edgelist(graph_df, 'from', 'to', edge_attr=['time'], create_using=nx.Graph())
    elif dataset_name == 'COLLMN':
        graph_path = join(folder_path, "CollegeMsgProcessed.txt")
        graph_df = pd.read_csv(graph_path, sep=',', usecols=['from', 'to', 'time'])

        graph_nx = nx.from_pandas_edgelist(graph_df, 'from', 'to', edge_attr=['time'], create_using=nx.Graph())
    elif dataset_name == 'FBFS':
        graph_path = join(folder_path, "facebookFriendshipLink.txt")
        graph_df = pd.read_csv(graph_path, sep=',', usecols=['from', 'to', 'time'])

        graph_nx = nx.from_pandas_edgelist(graph_df, 'from', 'to', edge_attr=['time'], create_using=nx.Graph())
    elif dataset_name == 'EUEMAIL':
        graph_path = join(folder_path, "emailEU.txt")
        graph_df = pd.read_csv(graph_path, sep=',', usecols=['from', 'to', 'time'])

        graph_nx = nx.from_pandas_edgelist(graph_df, 'from', 'to', edge_attr=['time'], create_using=nx.Graph())
    elif dataset_name == 'WIKIEDIT':
        graph_path = join(folder_path, "wikinewsusereditSmall.txt")#wikinewsusereditSmall,enWikiEditSmall
        graph_df = pd.read_csv(graph_path, sep=',', usecols=['from', 'to', 'time'])

        graph_nx = nx.from_pandas_edgelist(graph_df, 'from', 'to', edge_attr=['time'], create_using=nx.Graph())
    elif dataset_name == 'ARXHEPCOLL':
        graph_path = join(folder_path, "hepPhenoCollaboration.txt")
        graph_df = pd.read_csv(graph_path, sep=',', usecols=['from', 'to', 'time'])
        graph_nx = nx.from_pandas_edgelist(graph_df, 'from', 'to', edge_attr=['time'], create_using=nx.Graph())

    else:
        raise Exception('dataset not available')

    if not exists(dump_folder):
        os.mkdir(dump_folder)

    graphProperties(graph_nx)

    return graph_nx, dump_folder

def df2graph(graph_df, source, target, time, create_using=nx.Graph()):
    return nx.from_pandas_edgelist(graph_df, source, target, edge_attr=[time], create_using=create_using)

def graphProperties(graph_nx):
    print(nx.info(graph_nx))
    #exit(0)
    #print(len(graph_nx))
