from models.DGNN import DGNN
from models.static_model import StaticModel
