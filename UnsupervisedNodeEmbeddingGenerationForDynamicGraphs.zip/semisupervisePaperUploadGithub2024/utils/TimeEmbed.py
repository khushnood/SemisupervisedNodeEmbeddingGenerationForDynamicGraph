import torch
import numpy as np


class TimeEncode(torch.nn.Module):
  # Time Encoding proposed by TGAT
  def __init__(self, dimension):
    super(TimeEncode, self).__init__()

    self.dimension = dimension
    self.w = torch.nn.Linear(1, dimension)

    self.w.weight = torch.nn.Parameter((torch.from_numpy(1 / 10 ** np.linspace(0, 9, dimension)))
                                       .float().reshape(dimension, -1))
    self.w.bias = torch.nn.Parameter(torch.zeros(dimension).float())

  def forward(self, t):
    # t has shape [batch_size, seq_len]


    # Add dimension at the end to apply linear layer --> [batch_size, seq_len, 1]
    t = t.unsqueeze(dim=2)

    # output has shape [batch_size, seq_len, dimension]
    output = torch.cat([torch.cos(self.w(t)) , torch.sin(self.w(t)), self.w(t)],dim=1)

    return output
class Time2Vec(torch.nn.Module):
  def __init__(self,dim):
      """
      In the constructor we instantiate four parameters and assign them as
      member parameters.
      """
      super().__init__()
      self.w1 = torch.nn.Parameter(torch.randn(([1,dim])),requires_grad=True)
      self.b1 = torch.nn.Parameter(torch.randn(([1])),requires_grad=True)
      self.w2 = torch.nn.Parameter(torch.randn(([dim,1])),requires_grad=True)
      self.b2 = torch.nn.Parameter(torch.randn(([1])),requires_grad=False)

  def forward(self, x):
      """
      In the forward function we accept a Tensor of input data and we must return
      a Tensor of output data. We can use Modules defined in the constructor as
      well as arbitrary operators on Tensors.
      """
      output1=self.w1.T.matmul(x)+self.b1
      output1=torch.tanh(output1)
      output2=self.w2.T.matmul(output1)+self.b2
      #output=torch.cos(self.a + self.b * x + self.c * x ** 2 + self.c * x ** 3 )
      output=torch.cos(output2)
      return output

