from math import ceil

import models
import loader

from config import params
from metrics import get_metrics
from numpy.random import seed
#import tensorflow as tf
import numpy as np
import torch
import os
from os.path import join, exists

#Why results might be different
#https://determined.ai/blog/reproducibility-in-ml/

def run(**kwargs):
    # load graph
    model_name=kwargs['model_name']
    graph_nx, dump_folder = loader.load_dataset(kwargs['dataset'],'dump_'+model_name)


    # initialize tNodeEmbed
    task = kwargs['task']
    test_size = kwargs['test_size']



    dGNN = models.DGNN(graph_nx, task=task, dump_folder=dump_folder, test_size=test_size,model_name=model_name,align=False)

    # load dataset

    X, y = dGNN.get_dataset(train_skip=kwargs['train_skip'])
    # fit
    keras_args = kwargs['keras_args']
    batch_size = keras_args.pop('batch_size', 32)
    steps_per_epoch = ceil(len(X['train']) / batch_size)



    static_model = models.StaticModel(task=task)
    generator = loader.dataset_generator(X['train'], y['train'], dGNN.graph_nx, [max(dGNN.train_time_steps)], batch_size=batch_size)

    static_model.fit_generator(generator, steps_per_epoch, **keras_args)
    print("steps_per_epoch",steps_per_epoch)


    # predict
    steps = ceil(len(X['test']) / batch_size)
    temporalNodeEmbd_metrics={'roc_auc': 0.0,
            'pr_auc': 0.0,
            'thirdMetric': steps_per_epoch}

    #Forstatic models
    generator = loader.dataset_generator(X['test'], y['test'], dGNN.graph_nx, [max(dGNN.train_time_steps)], batch_size=batch_size, shuffle=False)
    staticModel_metrics = get_metrics(y['test'], static_model.predict_generator(generator, steps))


    print(f'static: {staticModel_metrics}:'+params['model_name'])
    result=temporalNodeEmbd_metrics['roc_auc'],temporalNodeEmbd_metrics['pr_auc'],temporalNodeEmbd_metrics['thirdMetric'],staticModel_metrics['roc_auc'],staticModel_metrics['pr_auc'],staticModel_metrics['thirdMetric']

    return [np.asarray(result),dump_folder]


if __name__ == '__main__':

    numOfExperiments=1
    isDeleteOldEmbed=True
    for model in (params['all_models']):
        params['model_name']=model

        for dataset in (params['datasets']):
            params['dataset']=dataset
            np.random.seed(1)
            torch.manual_seed(1)
            seed(1)
            resultMatr=np.zeros((numOfExperiments, 6), dtype='float')
            filePath = join(r"../data/results",dataset +'_result_'+params['model_name']+'.txt')       # print(filePath)

            if os.path.exists(filePath):
                append_write = 'a' # append if already exists
            else:
                append_write = 'w' # make a new file if not

            for expr in range(0,numOfExperiments):
                print("experimental iteraction",expr+1,": datatset ",dataset," model name: ",model)

                dump_folder = 'dump_'+model
                init_path = join(os.path.abspath(os.pardir),'data',dataset,dump_folder, 'init.emb')
                if os.path.exists(init_path) and isDeleteOldEmbed:
                    print(init_path)
                    os.remove(init_path);
                results=run(**params)
                resultMatr[expr,:]=results[0]
                dump_folder=results[1]


            print(f"average score after {numOfExperiments} iteration ",model,": ",model)
            f = open(filePath,append_write)
            print(str(resultMatr)+"   :dgnn 1:"+model, file=f)
            averageResult=np.sum(resultMatr,axis=0)/numOfExperiments
            stadDeviation=np.std(resultMatr,axis=0)
            print(averageResult)
            f = open(filePath,append_write)
            print(str(averageResult)+f" Average after  : {model} with RNN: {model} static", file=f)
            print(str(stadDeviation)+f"   : std after {numOfExperiments}:"+model, file=f)
            f.close()


