import os
from os.path import join

import networkx as nx
from networkx import to_numpy_matrix,from_numpy_matrix
import numpy as np
from tqdm import tqdm
from node2vec import Node2Vec
from scipy.linalg import orthogonal_procrustes
import scipy.sparse as sp
from keras import regularizers
from keras.layers import Input, LSTM, GRU, Dense, Activation, Concatenate, Lambda, Dropout, Embedding
from keras.models import Model,Sequential
#from numba import jit
#import cupy as cp
import loader
from models.task_model import TaskModel
from utils.graph_utils import get_graph_T, get_pivot_time, get_graph_times, multigraph2graph
from utils.general_utils import load_object, save_object
from utils.consts import TLP, NC, TLPXYZ
#from cogdl.models import build_model
#from cogdl import options
from argparse import Namespace
from utils.TimeEmbed import TimeEncode,Time2Vec
import torch
from scipy.stats import ortho_group
from procrustes import orthogonal,rotational
import random,math
from scipy.stats import poisson
class DGNN(TaskModel):
    def __init__(self, graph_nx, task, dump_folder, test_size=0, align=True,model_name='dgnn'):
        '''

        Args:
            graph_nx: networkx - holding the temporal graph
            task: str - name of the task. either 'temporal_link_prediction' or 'node_classification'
            dump_folder: string - link to a dump folder of the graph dataset, in order for future runs to run faster
            test_size: folat - the wanted size of test_size
            align: bool - True if alignment is wanted, else False

        '''
        super(DGNN, self).__init__(task=task)

        self.dump_folder = dump_folder
        self.test_size = test_size
        self.align = align

        self.model_name=model_name

        self.graph_nx = graph_nx
        times = get_graph_times(self.graph_nx)

        if self.task == TLP:
            self.pivot_time = self.calculate_pivot_time()
        else:
            self.pivot_time = times[-1]

        self.train_time_steps = times[times <= self.pivot_time]

        # initialize
        self.graph_nx = self.initialize()

    def get_dataset(self, train_skip=1):
        '''
        This function is responsible of creating the dataset of the wanted task from the given graph_nx. Wraps the
        function 'task_loader.load_task' for caching.
        Args:
            train_skip: float - ratio of the data we take for train. For example, if we have N possible
                                 samples in the given graph_nx, then we take only int(N/train_skip) samples for train.
                                 This is highly important in large graphs.
        Returns:
            X: dict - with keys 'train', 'test'. each value is a np.array of the dataset, where each entery is a sample
                      with the embeddings.
            y: dict - with keys 'train', 'test', each value is a np.array of the dataset, where y[key][i] is the label
                      of X[key][i] for the given task.
        '''
        # load task data
        task_data_path = join(self.dump_folder, f'{self.task}_dataset_{self.pivot_time}.data')
        if os.path.exists(task_data_path):
            X, y = load_object(task_data_path)
        else:
            X, y = loader.load_task(self.graph_nx, self.task, train_skip=1, pivot_time=self.pivot_time,
                                    test_size=self.test_size)
            save_object((X, y), task_data_path)

        X = {'train': X['train'][::train_skip], 'test': X['test']}
        y = {'train': y['train'][::train_skip], 'test': y['test']}

        return X, y

    @staticmethod
    def _get_model(task, input_shape, latent_dim=128, num_classes=1):
        '''
        Given the task, return the desired architecture of training
        Args:
            task: string - of the tasks name, either 'temporal_link_prediction' or 'node_classification'
            input_shape: tuple - shape of a singe sample
            latent_dim: int - the size of the LSTM latent space
            num_classes: int - number of classes. Relevant only if task=='node_classification'
        Returns:
            keras model of tNodeEmbed
        '''
        if task == TLP:

            inputs = Input(shape=input_shape)

            lmda_lyr1 = Lambda(lambda x: x[:, 0, :, :], output_shape=input_shape[1:])(inputs)
            lmda_lyr2 = Lambda(lambda x: x[:, 1, :, :], output_shape=input_shape[1:])(inputs)

            gru_lyr_siamese = GRU(latent_dim, return_sequences=False, activation='tanh',dropout=0.2)
			

            lstm_lyr1 = gru_lyr_siamese(lmda_lyr1)
            lstm_lyr2 = gru_lyr_siamese(lmda_lyr2)

            concat_lyr = Concatenate(axis=-1)([lstm_lyr1, lstm_lyr2])

            fc_lyr1 = Dense(latent_dim, activation='tanh',kernel_regularizer=regularizers.l2(0.01))(concat_lyr)

            fc_lyr2 = Dense(1)(fc_lyr1)
            soft_lyr = Activation('sigmoid')(fc_lyr2)

            model = Model(inputs, soft_lyr)

            model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
        else:
            raise Exception('unknown task for _get_model')
        return model

    def calculate_pivot_time(self):
        '''
        Calculate the pivot time that is needed in order to create a 'time_split_ratio' between train edges and
        test edges
        Returns:
            time step representing the pivot time step
        '''
        ratio2pivot = {}
        ratio2pivot_path = join(self.dump_folder, 'ratio2pivot.dict')
        if os.path.exists(ratio2pivot_path):
            ratio2pivot = load_object(ratio2pivot_path)
            if self.test_size in ratio2pivot:
                return ratio2pivot[self.test_size]
        pivot_time = get_pivot_time(self.graph_nx, self.test_size)
        ratio2pivot[self.test_size] = pivot_time
        save_object(ratio2pivot, ratio2pivot_path)
        return pivot_time

    def initialize(self):
        '''
        initialize the model by calculating embeddings per each time step and aligning them all together
        Returns:
            initialized netwrokx graph
        '''
        init_path = join(self.dump_folder, 'init.emb')
        if os.path.exists(init_path):
            graph_nx = nx.read_gpickle(init_path)
        else:
            # initialize embeddings  _initialize_embeddings_node2vec
            if(self.model_name=='dgnn'):
                graph_nx = DGNN._initialize_embeddings_HebbianImplementedDGNN(self.pivot_time,self.graph_nx, self.train_time_steps)

            else:
                graph_nx = DGNN._initialize_embeddings_static(self.pivot_time, self.graph_nx, self.train_time_steps, self.model_name)
            nx.write_gpickle(graph_nx, init_path)

        if self.align:

            graph_nx = DGNN._align_embeddings(graph_nx, self.train_time_steps)


        return graph_nx



    @staticmethod
    def _initialize_embeddings_HebbianImplementedDGNN(pivot_time,graph_nx, times=None):
        '''
        Given a graph, learn embeddings for all nodes in all time step. Attribute 'time' for each edge mast appear
        Args:
            graph_nx: networkx - the given graph
            times: list - of the times we want to work with, if None then calculates for all times in the graph


        Returns:
            graph_nx: networkx - but with attributes for each node for each time step of its embedding
        '''


        timestamps=nx.get_edge_attributes(graph_nx, 'time')
        output_dim_time_encode=64

        vals = np.fromiter(timestamps.values(), dtype=float)
        valstensor=torch.from_numpy(vals)
        valstensor=torch.reshape(valstensor,[1,vals.shape[0]])
        modelTimeEmbed =TimeEncode(output_dim_time_encode)
        timeEmbeddings=modelTimeEmbed(valstensor.float())
        timeEmbeddingsDict={}
        for indx in range(0,vals.shape[0]):
            emp=timeEmbeddings[0][indx]
            timeEmbeddingsDict[vals[indx]]=emp.detach().numpy()
        if times is None:
            times = get_graph_times(graph_nx)

        output_dim=64
        nodeFeatureMap=nx.get_node_attributes(graph_nx,"features") # see this is set in data loader section
        if not nodeFeatureMap:
            print("No node level features found")

        maxTime=np.max(times)
        final_graph_nx_t = get_graph_T(graph_nx, max_time=maxTime)
        final_graph_nx = multigraph2graph(final_graph_nx_t)


        for time in tqdm(times, desc='Time Steps', unit='time_step'):
            cur_graph_nx_1 = get_graph_T(graph_nx, max_time=time)
            cur_graph_nx = multigraph2graph(cur_graph_nx_1)

            if(cur_graph_nx.number_of_nodes()<2):
                learnedFeatures=np.random.uniform(-np.sqrt(1./output_dim), np.sqrt(1./output_dim), (cur_graph_nx.number_of_nodes(), 4*output_dim))
                for node in cur_graph_nx.nodes():
                    randFeatures={node:learnedFeatures[0,:].flat}
                nx.set_node_attributes(graph_nx, randFeatures, time)
                continue


            nodes =cur_graph_nx.nodes()
            G1_sub = cur_graph_nx.subgraph(nodes)
            G2_sub = final_graph_nx.subgraph(nodes)
            deg_G1 = dict(G1_sub.degree)
            deg_G2 = dict(G2_sub.degree)
            degree_gain = {node: deg_G2[node] - deg_G1[node] for node in nodes}
            node_index = {node: i for i, node in enumerate(nodes)}
            Adj = nx.adjacency_matrix(G1_sub, nodelist=nodes).toarray()
            degree_gain_vector = np.zeros(Adj.shape[0])
            for node, deg_gain in degree_gain.items():
                node_idx = node_index[node]
                degree_gain_vector[node_idx] = deg_gain

            constToavoidZeroError=1
            delta_t=maxTime+constToavoidZeroError-time
            rate = (1+degree_gain_vector) / delta_t
            I = np.eye(Adj.shape[0])
            A_hat=Adj+I
            nodeWiseIntensities=np.exp(rate*(time-(pivot_time+constToavoidZeroError)))
            A_hat=np.multiply(A_hat, nodeWiseIntensities[:, np.newaxis])


            nodeArrays=np.asarray(cur_graph_nx.nodes())

            if  nodeFeatureMap:
                features=np.zeros(shape=[Adj.shape[0],np.array(nodeFeatureMap.get(nodeArrays[0])).shape[0]])
                for nodeIndx in range(0,nodeArrays.shape[0]):
                    features[nodeIndx]=np.array(nodeFeatureMap.get(nodeArrays[nodeIndx]))

            else:
                features=np.eye(Adj.shape[0])



            input_dim=features.shape[1]

            hidden_dim=64
            if(hidden_dim<1):
                hidden_dim=1

            W_1 = np.random.uniform(-np.sqrt(1./hidden_dim), np.sqrt(1./hidden_dim), (input_dim, hidden_dim))
            W_hidden1 = np.random.uniform(-np.sqrt(1./hidden_dim), np.sqrt(1./hidden_dim), (W_1.shape[1], hidden_dim)) #check to correct here also
            W_hidden2 = np.random.uniform(-np.sqrt(1./output_dim), np.sqrt(1./output_dim), (W_1.shape[1], hidden_dim))
            W_out = np.random.uniform(-np.sqrt(1./hidden_dim), np.sqrt(1./hidden_dim), (W_1.shape[1], output_dim))
            nonlinear=True # gcn_layer_atn

            if nonlinear:

                H_1 = gcn_layer_atn(A_hat,  features, W_1)
                H_2 = gcn_layer_atn(A_hat,  H_1, W_hidden1)
                H_3 = gcn_layer_atn(A_hat,  H_2, W_out)
                learnedNodeFeaturestmp=H_3
                repeats_array_timeEmbed = np.tile(timeEmbeddingsDict.get(time), (learnedNodeFeaturestmp.shape[0], 1))
                embeddingWithTimePreviousConCat=np.concatenate([H_1,H_2,learnedNodeFeaturestmp], axis=1)
                embeddingWithTimeCon=np.concatenate([embeddingWithTimePreviousConCat,repeats_array_timeEmbed], axis=1)
                learnedNodeFeatures=embeddingWithTimeCon
                ##########################Optimising

                X_T = np.transpose(learnedNodeFeatures)

                alpha = 0.005
                num_iters = 200
                edges=np.nonzero(Adj)

                for i in range(num_iters):
                    for from_node, to_node in zip(*edges):
                        h = learnedNodeFeatures[from_node, :].dot(X_T[:, to_node])
                        e = 1/(1+np.exp(-h))
                        delta = alpha * (1 - e)

                        learnedNodeFeatures[from_node, :] += delta * X_T[:, to_node]
                        X_T[:, to_node] += delta * learnedNodeFeatures[from_node, :]

            else:

                H_1 = gcn_layer(A_hat,  features, W_1)
                H_2 = gcn_layer(A_hat,  H_1, W_hidden2)
                H_3 = gcn_layer(A_hat,  H_2, W_hidden2)
                H_4 = gcn_layer(A_hat,  H_3, W_hidden2)
                H_5 = gcn_layer(A_hat,  H_4, W_hidden2)
                H_6 = gcn_layer(A_hat,  H_5, W_hidden2)
                H_7 = gcn_layer(A_hat,  H_6, W_out)
                learnedNodeFeatures=H_7
			  



            learnedNodeFeaturesDict = {node: np.asarray(learnedNodeFeatures[nodeIndx,:].flat) for nodeIndx, node in enumerate(cur_graph_nx.nodes())}

            nx.set_node_attributes(graph_nx, learnedNodeFeaturesDict, time)




        return graph_nx



    @staticmethod
    def _initialize_embeddings_static(pivot_time, graph_nx, times=None, model_name='prone'):
        '''

        :param pivot_time:
        :param graph_nx:
        :param times:
        :param model_name:

        :return:graph_nx to be implemented
        '''

        return graph_nx

    @staticmethod
    def _align_embeddings(graph_nx, times=None):
        '''
        Given a graph that went through 'initialize_embeddings', align all time step embeddings to one another
        Args:
            graph_nx: networkx - the given graph
            times: list - of the times we want to work with, if None then calculates for all times in the graph

        Returns:
            graph_nx: networkx - with aligned embeddings in its attributes for each node
        '''
        if times is None:
            times = get_graph_times(graph_nx)

        node2Q_t_1 = nx.get_node_attributes(graph_nx, times[0])
        Q_t_1 = np.array([node2Q_t_1[node] for node in node2Q_t_1])

        for time in times[1:]:
            node2Q_t = nx.get_node_attributes(graph_nx, time)
            Q_t = np.array([node2Q_t[node] for node in node2Q_t_1])

            result = rotational(Q_t, Q_t_1, scale=False, translate=False)
            R_t = result.t

            Q_t = np.array([node2Q_t[node] for node in node2Q_t])
            R_tQ_t = np.dot(Q_t, R_t)
            node2R_tQ_t = {node: vec for node, vec in zip(node2Q_t, R_tQ_t)}
            nx.set_node_attributes(graph_nx, node2R_tQ_t, time)
            node2Q_t_1 = node2R_tQ_t
            Q_t_1 = R_tQ_t

        return graph_nx




def gcn_layer(A_hat,  X, W):
    """

    :param A_hat:
    :param X:
    :param W:
    :return:
    """
    forward=A_hat.dot(X).dot(W)
    return forward

def gcn_layer_atn(A_hat,  X, W):
    """

    :param A_hat:
    :param X:
    :param W:
    :return:
    """
    temp=softmax(X.dot(W),axis=1)
    forward=A_hat.dot(temp)
    return forward
def gcn_layer_torch(A_hat,  X, W):
    """

    :param A_hat:
    :param X:
    :param W:
    :return:
    """
    temp=torch.nn.functional.softmax(torch.mm(X, W), dim=1)
    forward = torch.mm(A_hat, temp)
    return forward


def softmax(X, theta = 1.0, axis = None):
    """
    Compute the softmax of each element along an axis of X.

    Parameters
    ----------
    X: ND-Array. Probably should be floats.
    theta (optional): float parameter, used as a multiplier
        prior to exponentiation. Default = 1.0
    axis (optional): axis to compute values along. Default is the
        first non-singleton axis.

    Returns an array the same size as X. The result will sum to 1
    along the specified axis.
    """
    X=np.array(X)
    # make X at least 2d
    y = np.atleast_2d(X)

    # find axis
    if axis is None:
        axis = next(j[0] for j in enumerate(y.shape) if j[1] > 1)

    # multiply y against the theta parameter,
    y = y * float(theta)

    # subtract the max for numerical stability
    y = y - np.expand_dims(np.max(y, axis = axis), axis)

    # exponentiate y
    y = np.exp(y)

    # take the sum along the specified axis
    ax_sum = np.expand_dims(np.sum(y, axis = axis), axis)

    # finally: divide elementwise
    p = y / ax_sum

    # flatten if X was 1D
    if len(X.shape) == 1: p = p.flatten()

    return p
def normalize_features(mx):
    """Row-normalize sparse matrix"""
    rowsum = np.array(mx.sum(1))
    r_inv = np.power(rowsum, -1).flatten()
    r_inv[np.isinf(r_inv)] = 0.
    r_mat_inv = sp.diags(r_inv)
    mx = r_mat_inv.dot(mx)
    return mx
def normalize_spectral(adj):
    """Symmetrically normalize adjacency matrix."""
    #adj = sp.coo_matrix(adj)
    rowsum = np.array(adj.sum(1))
    d_inv_sqrt = np.power(rowsum, -0.5).flatten()
    d_inv_sqrt[np.isinf(d_inv_sqrt)] = 0.
    d_mat_inv_sqrt = sp.diags(d_inv_sqrt)
    return adj.dot(d_mat_inv_sqrt).transpose().dot(d_mat_inv_sqrt)

def softmax_rowwise(matrix):
    return np.exp(matrix) / np.sum(np.exp(matrix), axis=1)

def deepwalk_mine(A, num_walks, walk_length, window_size, emb_size, num_iters = 10):
    """
    A: Adjacency matrix of the graph
    num_walks: number of random walks for each node
    walk_length: length of each random walk
    window_size: window size for the Skip-Gram model
    emb_size: size of the embeddings
    """
    walks = []
    nodes = range(A.shape[0])

    for node in nodes:
        for i in range(num_walks):
            walk = [node]
            current_node = node
            for j in range(walk_length-1):
                neighbors = np.where(A[current_node,:] != 0)[0]
                if len(neighbors) > 0:
                    next_node = random.choice(neighbors)
                else:
                    next_node = node
                walk.append(next_node)
                current_node = next_node
            walks.append(walk)

    pairs = []
    for walk in walks:
        for i in range(len(walk)):
            for j in range(i+1, min(i+window_size, len(walk))):
                pairs.append((walk[i], walk[j]))

    X = []
    Y = []
    for pair in pairs:
        X.append(pair[0])
        Y.append(pair[1])

    X = np.array(X)
    Y = np.array(Y)

    W1 = np.random.rand(A.shape[0], emb_size)
    W2 = np.random.rand(emb_size, A.shape[0])

    alpha = 0.025


    for i in range(num_iters):
        for x, y in zip(X, Y):
            h = W1[x, :].dot(W2[:, y])
            e = 1/(1+np.exp(-h))
            delta = alpha * (1 - e)
            W1[x, :] += delta * W2[:, y]
            W2[:, y] += delta * W1[x, :]

    emb = W1
    return emb
